const themeButton = document.getElementById("themeButton");
const helloButton = document.getElementById("helloButton");
const message = document.getElementById("message");

// Переключение светлой и тёмной темы
themeButton.addEventListener("click", function () {
    document.body.classList.toggle("dark");

    if (document.body.classList.contains("dark")) {
        themeButton.textContent = "☀️ Светлая тема";
    } else {
        themeButton.textContent = "🌙 Тёмная тема";
    }
});

// Изменение текста по нажатию кнопки
helloButton.addEventListener("click", function () {
    message.textContent = "Привет! Спасибо, что заглянул на мою страницу 👋";
});
